This is adaptation of the work of Fabio Veronesi 
Copy Right: Fabio Veronesi