# server.R  
library(sp)  
library(rjson)  

shinyServer(function(input, output, session) { }) 
  
    